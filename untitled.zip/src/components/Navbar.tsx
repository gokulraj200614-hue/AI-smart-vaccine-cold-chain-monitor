import React, { useState } from "react";
import { useColdChain } from "../context/ColdChainContext";
import { UserRole } from "../types";
import { 
  ShieldAlert, 
  Activity, 
  Truck, 
  Stethoscope, 
  Settings, 
  Volume2, 
  VolumeX, 
  Bot, 
  Flame, 
  Radio, 
  CheckCircle2, 
  AlertTriangle,
  RefreshCw,
  Cpu
} from "lucide-react";

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab }) => {
  const { 
    userRole, 
    setUserRole, 
    alerts, 
    soundAlarmEnabled, 
    setSoundAlarmEnabled,
    triggerChaos,
    selectedDeviceId,
    selectedDevice,
    setCopilotOpen,
    fetchData
  } = useColdChain();

  const [chaosMenuOpen, setChaosMenuOpen] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const activeCriticalCount = alerts.filter(a => a.status === "active" && a.severity === "critical").length;
  const activeWarningCount = alerts.filter(a => a.status === "active" && a.severity === "warning").length;

  const handleManualRefresh = async () => {
    setIsRefreshing(true);
    await fetchData();
    setTimeout(() => setIsRefreshing(false), 600);
  };

  return (
    <header className="sticky top-0 z-40 bg-slate-900 border-b border-slate-800 text-slate-100 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo & Pipeline Badge */}
          <div className="flex items-center space-x-3">
            <div className="flex items-center space-x-2">
              <div className="w-9 h-9 rounded-lg bg-gradient-to-tr from-cyan-600 to-blue-500 flex items-center justify-center shadow-lg shadow-cyan-500/20 ring-1 ring-cyan-400/30">
                <Activity className="w-5 h-5 text-white animate-pulse" />
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <span className="font-extrabold tracking-wider text-xl bg-gradient-to-r from-white via-cyan-100 to-cyan-400 bg-clip-text text-transparent">
                    ECHELON
                  </span>
                  <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 bg-cyan-950 text-cyan-400 border border-cyan-800/60 rounded">
                    AI Cold-Chain
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 hidden sm:block">
                  SHT33 Telemetry • Edge Buffer • Gemini Risk Engine
                </p>
              </div>
            </div>

            {/* Live Pipeline Telemetry Indicator */}
            <div className="hidden xl:flex items-center space-x-1 pl-4 border-l border-slate-800 text-xs">
              <span className="flex h-2 w-2 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              <span className="text-slate-400 font-mono text-[11px]">
                {selectedDevice?.isOnline ? "Cloud Stream Active (3.5s)" : "Edge Flash Buffering"}
              </span>
            </div>
          </div>

          {/* Navigation Tabs */}
          <nav className="hidden md:flex items-center space-x-1 bg-slate-950/80 p-1 rounded-xl border border-slate-800/80">
            <button
              id="nav-tab-overview"
              onClick={() => setActiveTab("overview")}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center space-x-1.5 ${
                activeTab === "overview"
                  ? "bg-cyan-600 text-white shadow-sm shadow-cyan-600/30"
                  : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/60"
              }`}
            >
              <Activity className="w-3.5 h-3.5" />
              <span>Smart Monitor</span>
            </button>

            <button
              id="nav-tab-transport"
              onClick={() => setActiveTab("transport")}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center space-x-1.5 ${
                activeTab === "transport"
                  ? "bg-cyan-600 text-white shadow-sm shadow-cyan-600/30"
                  : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/60"
              }`}
            >
              <Truck className="w-3.5 h-3.5" />
              <span>Transport Fleet</span>
            </button>

            <button
              id="nav-tab-batches"
              onClick={() => setActiveTab("batches")}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center space-x-1.5 ${
                activeTab === "batches"
                  ? "bg-cyan-600 text-white shadow-sm shadow-cyan-600/30"
                  : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/60"
              }`}
            >
              <Stethoscope className="w-3.5 h-3.5" />
              <span>Vaccine Lots</span>
            </button>

            <button
              id="nav-tab-alerts"
              onClick={() => setActiveTab("alerts")}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center space-x-1.5 relative ${
                activeTab === "alerts"
                  ? "bg-cyan-600 text-white shadow-sm shadow-cyan-600/30"
                  : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/60"
              }`}
            >
              <ShieldAlert className="w-3.5 h-3.5" />
              <span>Alerts Hub</span>
              {(activeCriticalCount > 0 || activeWarningCount > 0) && (
                <span className={`ml-1 px-1.5 py-0.2 text-[10px] font-bold rounded-full text-white ${
                  activeCriticalCount > 0 ? "bg-rose-600 animate-pulse" : "bg-amber-500"
                }`}>
                  {activeCriticalCount + activeWarningCount}
                </span>
              )}
            </button>

            <button
              id="nav-tab-edge"
              onClick={() => setActiveTab("edge")}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center space-x-1.5 ${
                activeTab === "edge"
                  ? "bg-cyan-600 text-white shadow-sm shadow-cyan-600/30"
                  : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/60"
              }`}
            >
              <Cpu className="w-3.5 h-3.5" />
              <span>Edge & Buffer</span>
            </button>

            <button
              id="nav-tab-reports"
              onClick={() => setActiveTab("reports")}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center space-x-1.5 ${
                activeTab === "reports"
                  ? "bg-cyan-600 text-white shadow-sm shadow-cyan-600/30"
                  : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/60"
              }`}
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Compliance & Audit</span>
            </button>
          </nav>

          {/* Right Controls & Role Switcher */}
          <div className="flex items-center space-x-2.5">
            
            {/* User Role Selector */}
            <div className="relative flex items-center bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
              <span className="text-[10px] text-slate-500 font-mono px-1 hidden lg:inline">ROLE:</span>
              <select
                id="role-select"
                value={userRole}
                onChange={(e) => setUserRole(e.target.value as UserRole)}
                className="bg-transparent text-slate-200 font-medium text-xs rounded focus:outline-none focus:ring-1 focus:ring-cyan-500 cursor-pointer pr-2"
              >
                <option value="healthcare_worker" className="bg-slate-900 text-slate-100">
                  🩺 Healthcare Worker
                </option>
                <option value="transport_personnel" className="bg-slate-900 text-slate-100">
                  🚚 Transport Logistics
                </option>
                <option value="administrator" className="bg-slate-900 text-slate-100">
                  🛡️ Administrator
                </option>
              </select>
            </div>

            {/* Audio Alarm Toggle */}
            <button
              id="toggle-sound-alarm"
              onClick={() => setSoundAlarmEnabled(!soundAlarmEnabled)}
              title={soundAlarmEnabled ? "Mute Audible Alarm Tone" : "Enable Audible Alarm Tone"}
              className={`p-2 rounded-lg border text-xs transition-colors ${
                soundAlarmEnabled
                  ? "bg-slate-800 border-slate-700 text-cyan-400 hover:bg-slate-700"
                  : "bg-slate-900 border-slate-800 text-slate-500 hover:text-slate-300"
              }`}
            >
              {soundAlarmEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>

            {/* Manual Sync/Refresh */}
            <button
              id="manual-refresh-btn"
              onClick={handleManualRefresh}
              title="Poll latest sensor packets"
              className="p-2 rounded-lg bg-slate-800 border border-slate-700 text-slate-300 hover:text-white hover:bg-slate-700 transition-colors"
            >
              <RefreshCw className={`w-4 h-4 ${isRefreshing ? "animate-spin text-cyan-400" : ""}`} />
            </button>

            {/* Chaos Injection Simulator Dropdown */}
            <div className="relative">
              <button
                id="chaos-menu-toggle"
                onClick={() => setChaosMenuOpen(!chaosMenuOpen)}
                className="px-2.5 py-1.5 rounded-lg bg-gradient-to-r from-amber-600 to-rose-600 text-white text-xs font-semibold flex items-center space-x-1 hover:brightness-110 shadow-sm transition-all"
              >
                <Flame className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Simulate Fault</span>
              </button>

              {chaosMenuOpen && (
                <div 
                  className="absolute right-0 mt-2 w-64 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl p-2 z-50 animate-in fade-in slide-in-from-top-2 duration-150"
                  onMouseLeave={() => setChaosMenuOpen(false)}
                >
                  <div className="text-[11px] font-bold text-slate-400 px-2 py-1 uppercase tracking-wider border-b border-slate-800 mb-1">
                    Inject Sensor & Cold-Chain Faults
                  </div>
                  <button
                    onClick={() => {
                      triggerChaos("door_open", selectedDeviceId);
                      setChaosMenuOpen(false);
                    }}
                    className="w-full text-left px-2.5 py-1.5 text-xs text-slate-200 hover:bg-slate-800 rounded-lg flex items-center space-x-2 transition-colors"
                  >
                    <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <div>
                      <div className="font-semibold text-slate-100">Door Ajar / Seal Breach</div>
                      <div className="text-[10px] text-slate-400">+4.2°C thermal infiltration</div>
                    </div>
                  </button>

                  <button
                    onClick={() => {
                      triggerChaos("compressor_failure", selectedDeviceId);
                      setChaosMenuOpen(false);
                    }}
                    className="w-full text-left px-2.5 py-1.5 text-xs text-slate-200 hover:bg-slate-800 rounded-lg flex items-center space-x-2 transition-colors"
                  >
                    <AlertTriangle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                    <div>
                      <div className="font-semibold text-slate-100">Cooling Compressor Failure</div>
                      <div className="text-[10px] text-slate-400">+5.8°C decay curve</div>
                    </div>
                  </button>

                  <button
                    onClick={() => {
                      triggerChaos("freeze_drop", selectedDeviceId);
                      setChaosMenuOpen(false);
                    }}
                    className="w-full text-left px-2.5 py-1.5 text-xs text-slate-200 hover:bg-slate-800 rounded-lg flex items-center space-x-2 transition-colors"
                  >
                    <AlertTriangle className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                    <div>
                      <div className="font-semibold text-slate-100">Sub-Zero Freeze Spike (-1.5°C)</div>
                      <div className="text-[10px] text-slate-400">Adjuvant denaturing hazard</div>
                    </div>
                  </button>

                  <button
                    onClick={() => {
                      triggerChaos("heat_spike", selectedDeviceId);
                      setChaosMenuOpen(false);
                    }}
                    className="w-full text-left px-2.5 py-1.5 text-xs text-slate-200 hover:bg-slate-800 rounded-lg flex items-center space-x-2 transition-colors"
                  >
                    <Flame className="w-3.5 h-3.5 text-rose-500 shrink-0" />
                    <div>
                      <div className="font-semibold text-slate-100">Ambient Heat Wave (+38°C)</div>
                      <div className="text-[10px] text-slate-400">Exceeds thermal insulation capacity</div>
                    </div>
                  </button>

                  <div className="border-t border-slate-800 mt-1 pt-1">
                    <button
                      onClick={() => {
                        triggerChaos("normal_reset", selectedDeviceId);
                        setChaosMenuOpen(false);
                      }}
                      className="w-full text-left px-2.5 py-1.5 text-xs text-emerald-400 hover:bg-emerald-950/40 rounded-lg flex items-center space-x-2 transition-colors font-semibold"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Reset to Nominal Setpoint</span>
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* AI Copilot Button */}
            <button
              id="open-ai-copilot-btn"
              onClick={() => setCopilotOpen(true)}
              className="px-3 py-1.5 rounded-lg bg-cyan-950 hover:bg-cyan-900 border border-cyan-700/60 text-cyan-300 text-xs font-semibold flex items-center space-x-1.5 transition-all shadow-sm"
            >
              <Bot className="w-4 h-4 text-cyan-400 animate-bounce" />
              <span className="hidden sm:inline">AI Copilot</span>
            </button>

          </div>
        </div>

        {/* Mobile Navigation bar */}
        <div className="md:hidden flex overflow-x-auto space-x-1 py-2 border-t border-slate-800 text-xs">
          <button
            onClick={() => setActiveTab("overview")}
            className={`px-3 py-1 rounded-md shrink-0 ${activeTab === "overview" ? "bg-cyan-600 text-white" : "text-slate-400"}`}
          >
            Monitor
          </button>
          <button
            onClick={() => setActiveTab("transport")}
            className={`px-3 py-1 rounded-md shrink-0 ${activeTab === "transport" ? "bg-cyan-600 text-white" : "text-slate-400"}`}
          >
            Fleet GPS
          </button>
          <button
            onClick={() => setActiveTab("batches")}
            className={`px-3 py-1 rounded-md shrink-0 ${activeTab === "batches" ? "bg-cyan-600 text-white" : "text-slate-400"}`}
          >
            Vaccine Lots
          </button>
          <button
            onClick={() => setActiveTab("alerts")}
            className={`px-3 py-1 rounded-md shrink-0 ${activeTab === "alerts" ? "bg-cyan-600 text-white" : "text-slate-400"}`}
          >
            Alerts ({activeCriticalCount + activeWarningCount})
          </button>
          <button
            onClick={() => setActiveTab("edge")}
            className={`px-3 py-1 rounded-md shrink-0 ${activeTab === "edge" ? "bg-cyan-600 text-white" : "text-slate-400"}`}
          >
            Edge Buffer
          </button>
          <button
            onClick={() => setActiveTab("reports")}
            className={`px-3 py-1 rounded-md shrink-0 ${activeTab === "reports" ? "bg-cyan-600 text-white" : "text-slate-400"}`}
          >
            Compliance
          </button>
        </div>

      </div>
    </header>
  );
};
