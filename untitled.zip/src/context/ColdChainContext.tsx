import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode } from "react";
import { 
  ColdChainDevice, 
  SensorReading, 
  VaccineBatch, 
  VaccineProfile, 
  AlertNotification, 
  CorrectiveActionLog, 
  TransportShipment, 
  UserRole,
  AiRiskAnalysisResult 
} from "../types.ts";

interface ColdChainContextType {
  devices: ColdChainDevice[];
  selectedDevice: ColdChainDevice | null;
  selectedDeviceId: string;
  setSelectedDeviceId: (id: string) => void;
  telemetry: SensorReading[];
  batches: VaccineBatch[];
  profiles: VaccineProfile[];
  alerts: AlertNotification[];
  shipments: TransportShipment[];
  actions: CorrectiveActionLog[];
  userRole: UserRole;
  setUserRole: (role: UserRole) => void;
  isLoading: boolean;
  soundAlarmEnabled: boolean;
  setSoundAlarmEnabled: (enabled: boolean) => void;
  aiAnalysisModalOpen: boolean;
  setAiAnalysisModalOpen: (open: boolean) => void;
  aiAnalysisData: AiRiskAnalysisResult | null;
  aiAnalysisLoading: boolean;
  actionModalOpen: boolean;
  setActionModalOpen: (open: boolean) => void;
  targetAlertForAction: AlertNotification | null;
  setTargetAlertForAction: (alert: AlertNotification | null) => void;
  copilotOpen: boolean;
  setCopilotOpen: (open: boolean) => void;
  fetchData: () => Promise<void>;
  toggleConnectivity: (deviceId: string) => Promise<void>;
  triggerChaos: (type: string, deviceId: string) => Promise<void>;
  acknowledgeAlert: (alertId: string) => Promise<void>;
  resolveAlert: (alertId: string, correctiveActionTaken: string, notes: string) => Promise<void>;
  logCorrectiveAction: (actionData: Partial<CorrectiveActionLog>) => Promise<void>;
  submitShipmentHandover: (shipmentId: string, data: any) => Promise<void>;
  updateBatchStatus: (batchId: string, status: any, notes?: string) => Promise<void>;
  runAiThermodynamicAnalysis: (deviceId: string) => Promise<void>;
  sendTestAlertDispatch: (channel: string, recipient: string, message: string) => Promise<any>;
}

const ColdChainContext = createContext<ColdChainContextType | undefined>(undefined);

export const ColdChainProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [devices, setDevices] = useState<ColdChainDevice[]>([]);
  const [selectedDeviceId, setSelectedDeviceId] = useState<string>("DEV-ULT-801");
  const [telemetry, setTelemetry] = useState<SensorReading[]>([]);
  const [batches, setBatches] = useState<VaccineBatch[]>([]);
  const [profiles, setProfiles] = useState<VaccineProfile[]>([]);
  const [alerts, setAlerts] = useState<AlertNotification[]>([]);
  const [shipments, setShipments] = useState<TransportShipment[]>([]);
  const [actions, setActions] = useState<CorrectiveActionLog[]>([]);
  const [userRole, setUserRole] = useState<UserRole>("healthcare_worker");
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [soundAlarmEnabled, setSoundAlarmEnabled] = useState<boolean>(true);

  // Modals
  const [aiAnalysisModalOpen, setAiAnalysisModalOpen] = useState<boolean>(false);
  const [aiAnalysisData, setAiAnalysisData] = useState<AiRiskAnalysisResult | null>(null);
  const [aiAnalysisLoading, setAiAnalysisLoading] = useState<boolean>(false);

  const [actionModalOpen, setActionModalOpen] = useState<boolean>(false);
  const [targetAlertForAction, setTargetAlertForAction] = useState<AlertNotification | null>(null);
  const [copilotOpen, setCopilotOpen] = useState<boolean>(false);

  // Audio tone generator for critical alarm simulation
  const playAlarmTone = useCallback(() => {
    if (!soundAlarmEnabled) return;
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(880, ctx.currentTime); // A5 note
      osc.frequency.exponentialRampToValueAtTime(440, ctx.currentTime + 0.3);
      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.3);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.3);
    } catch {
      // Audio context might be restricted before user gesture
    }
  }, [soundAlarmEnabled]);

  const fetchData = useCallback(async () => {
    try {
      const [devRes, batchRes, alertRes, shipRes, actRes] = await Promise.all([
        fetch("/api/devices"),
        fetch("/api/batches"),
        fetch("/api/alerts"),
        fetch("/api/shipments"),
        fetch("/api/actions")
      ]);

      const devData = await devRes.json();
      const batchData = await batchRes.json();
      const alertData = await alertRes.json();
      const shipData = await shipRes.json();
      const actData = await actRes.json();

      if (devData.devices) {
        setDevices(devData.devices);
        if (!selectedDeviceId && devData.devices.length > 0) {
          setSelectedDeviceId(devData.devices[0].id);
        }
      }

      if (batchData.batches) setBatches(batchData.batches);
      if (batchData.profiles) setProfiles(batchData.profiles);
      if (alertData.alerts) {
        setAlerts(alertData.alerts);
        // Check if any critical active alert exists
        const hasActiveCritical = alertData.alerts.some((a: AlertNotification) => a.status === "active" && a.severity === "critical");
        if (hasActiveCritical) {
          playAlarmTone();
        }
      }
      if (shipData.shipments) setShipments(shipData.shipments);
      if (actData.actions) setActions(actData.actions);

      // Fetch telemetry for currently selected device
      const currentId = selectedDeviceId || (devData.devices?.[0]?.id);
      if (currentId) {
        const telRes = await fetch(`/api/devices/${currentId}/telemetry?limit=40`);
        const telData = await telRes.json();
        if (telData.readings) {
          setTelemetry(telData.readings);
        }
      }
    } catch (err) {
      console.error("Failed to fetch cold-chain state:", err);
    } finally {
      setIsLoading(false);
    }
  }, [selectedDeviceId, playAlarmTone]);

  // Initial fetch & continuous background polling
  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 3500);
    return () => clearInterval(interval);
  }, [fetchData]);

  // When selected device changes, immediately load its telemetry
  useEffect(() => {
    if (!selectedDeviceId) return;
    fetch(`/api/devices/${selectedDeviceId}/telemetry?limit=40`)
      .then(res => res.json())
      .then(data => {
        if (data.readings) setTelemetry(data.readings);
      })
      .catch(err => console.error("Telemetry fetch error:", err));
  }, [selectedDeviceId]);

  const selectedDevice = devices.find(d => d.id === selectedDeviceId) || devices[0] || null;

  const toggleConnectivity = async (deviceId: string) => {
    try {
      const res = await fetch(`/api/devices/${deviceId}/toggle-connectivity`, { method: "POST" });
      const data = await res.json();
      await fetchData();
    } catch (err) {
      console.error("Toggle connectivity error:", err);
    }
  };

  const triggerChaos = async (type: string, deviceId: string) => {
    try {
      await fetch("/api/simulate/chaos", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type, deviceId })
      });
      await fetchData();
    } catch (err) {
      console.error("Chaos error:", err);
    }
  };

  const acknowledgeAlert = async (alertId: string) => {
    try {
      await fetch(`/api/alerts/${alertId}/acknowledge`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ acknowledgedBy: `${userRole.replace("_", " ").toUpperCase()}` })
      });
      await fetchData();
    } catch (err) {
      console.error("Acknowledge alert error:", err);
    }
  };

  const resolveAlert = async (alertId: string, correctiveActionTaken: string, notes: string) => {
    try {
      await fetch(`/api/alerts/${alertId}/resolve`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          resolvedBy: `${userRole.replace("_", " ").toUpperCase()}`,
          correctiveActionTaken,
          notes
        })
      });
      await fetchData();
    } catch (err) {
      console.error("Resolve alert error:", err);
    }
  };

  const logCorrectiveAction = async (actionData: Partial<CorrectiveActionLog>) => {
    try {
      await fetch("/api/actions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...actionData,
          userRole
        })
      });
      await fetchData();
    } catch (err) {
      console.error("Log action error:", err);
    }
  };

  const submitShipmentHandover = async (shipmentId: string, data: any) => {
    try {
      await fetch(`/api/shipments/${shipmentId}/handover`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
      });
      await fetchData();
    } catch (err) {
      console.error("Handover error:", err);
    }
  };

  const updateBatchStatus = async (batchId: string, status: any, notes?: string) => {
    try {
      await fetch(`/api/batches/${batchId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          status,
          notes,
          lastInspectedBy: userRole.replace("_", " ").toUpperCase()
        })
      });
      await fetchData();
    } catch (err) {
      console.error("Update batch error:", err);
    }
  };

  const runAiThermodynamicAnalysis = async (deviceId: string) => {
    setAiAnalysisLoading(true);
    setAiAnalysisModalOpen(true);
    try {
      const res = await fetch("/api/ai/analyze-risk", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ deviceId })
      });
      const data = await res.json();
      if (data.result) {
        setAiAnalysisData(data.result);
      }
    } catch (err) {
      console.error("AI Analysis error:", err);
    } finally {
      setAiAnalysisLoading(false);
    }
  };

  const sendTestAlertDispatch = async (channel: string, recipient: string, message: string) => {
    const res = await fetch("/api/alerts/test-dispatch", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ channel, recipient, message })
    });
    return await res.json();
  };

  return (
    <ColdChainContext.Provider
      value={{
        devices,
        selectedDevice,
        selectedDeviceId,
        setSelectedDeviceId,
        telemetry,
        batches,
        profiles,
        alerts,
        shipments,
        actions,
        userRole,
        setUserRole,
        isLoading,
        soundAlarmEnabled,
        setSoundAlarmEnabled,
        aiAnalysisModalOpen,
        setAiAnalysisModalOpen,
        aiAnalysisData,
        aiAnalysisLoading,
        actionModalOpen,
        setActionModalOpen,
        targetAlertForAction,
        setTargetAlertForAction,
        copilotOpen,
        setCopilotOpen,
        fetchData,
        toggleConnectivity,
        triggerChaos,
        acknowledgeAlert,
        resolveAlert,
        logCorrectiveAction,
        submitShipmentHandover,
        updateBatchStatus,
        runAiThermodynamicAnalysis,
        sendTestAlertDispatch
      }}
    >
      {children}
    </ColdChainContext.Provider>
  );
};

export const useColdChain = () => {
  const context = useContext(ColdChainContext);
  if (!context) {
    throw new Error("useColdChain must be used within a ColdChainProvider");
  }
  return context;
};
