export type UserRole = 'healthcare_worker' | 'transport_personnel' | 'administrator';

export type RiskLevel = 'safe' | 'warning' | 'critical';

export interface VaccineProfile {
  id: string;
  name: string;
  category: 'mRNA' | 'Viral Vector' | 'Inactivated' | 'Live Attenuated' | 'Subunit';
  targetMinTemp: number; // °C
  targetMaxTemp: number; // °C
  targetMinHumidity: number; // %
  targetMaxHumidity: number; // %
  criticalHighTemp: number; // °C
  criticalLowTemp: number; // °C
  maxExcursionMinutes: number; // Total allowable time outside target before spoilage
  sensitivity: 'High (Freezing & Heat)' | 'Ultra-Cold mRNA' | 'Heat Sensitive' | 'Freeze Sensitive';
  manufacturer: string;
  recommendedStorage: string;
}

export interface VaccineBatch {
  id: string;
  batchNumber: string;
  vaccineId: string;
  vaccineName: string;
  quantityDoses: number;
  expiryDate: string;
  manufactureDate: string;
  assignedDeviceId: string;
  status: 'safe' | 'warning' | 'critical' | 'quarantined' | 'administered' | 'discarded';
  currentTemp: number;
  cumulativeExcursionMinutes: number;
  meanKineticTemperature: number; // MKT °C
  stabilityIndex: number; // 0-100% remaining viability
  lastInspectedBy?: string;
  lastInspectedAt?: string;
  notes?: string;
}

export interface SensorReading {
  id: string;
  deviceId: string;
  timestamp: string;
  temperature: number; // °C
  humidity: number; // %
  ambientTemp?: number;
  batteryLevel: number; // %
  signalStrength: number; // dBm
  rawVoltages?: { vdd: number; sda: number; scl: number };
  crcValid: boolean;
  bufferedAtEdge: boolean;
  rateOfChange: number; // °C / hour
  riskScore: number; // 0-100
  riskLevel: RiskLevel;
  anomalyDetected?: string;
}

export type DeviceType = 
  | 'ULTRA_LOW_FREEZER' // -80°C to -60°C
  | 'STANDARD_PHARMA_FRIDGE' // +2°C to +8°C
  | 'REEFER_TRANSIT_VAN' // Active mobile unit +2°C to +8°C
  | 'SOLAR_DIRECT_DRIVE_COOLER' // Off-grid clinic +2°C to +8°C
  | 'PASSIVE_VIP_SHIPPER'; // Vacuum Insulated Box + Dry Ice

export interface ColdChainDevice {
  id: string;
  name: string;
  code: string;
  type: DeviceType;
  locationName: string;
  facilityType: 'Central Vaccine Depot' | 'Regional Hub' | 'Transit Fleet' | 'Remote Health Post' | 'Urban Clinic';
  status: 'active' | 'offline_buffering' | 'syncing' | 'alarm' | 'maintenance';
  targetTempMin: number;
  targetTempMax: number;
  currentTemp: number;
  currentHumidity: number;
  rateOfChange: number; // °C/hour
  lastSyncTimestamp: string;
  bufferQueueCount: number; // Offline buffered items
  isOnline: boolean;
  powerSource: 'Mains Grid' | 'Backup Diesel Generator' | 'Solar Battery' | 'Vehicle Alternator' | 'Passive Thermal Pack';
  compressorState: 'running' | 'idle' | 'fault';
  doorState: 'closed' | 'open' | 'ajar_warning';
  activeBatchIds: string[];
  gps?: {
    lat: number;
    lng: number;
    speedKmH: number;
    heading: number;
    routeOrigin: string;
    routeDestination: string;
    estimatedArrival: string;
  };
}

export interface AlertNotification {
  id: string;
  deviceId: string;
  deviceName: string;
  batchIds: string[];
  timestamp: string;
  severity: 'warning' | 'critical';
  title: string;
  message: string;
  currentValue: number;
  thresholdValue: number;
  parameter: 'temperature' | 'humidity' | 'rate_of_change' | 'door_open' | 'offline_timeout' | 'ai_predictive_risk';
  channelsDispatched: {
    email: boolean;
    sms: boolean;
    push: boolean;
    siren: boolean;
  };
  status: 'active' | 'acknowledged' | 'resolved';
  acknowledgedBy?: string;
  acknowledgedAt?: string;
  resolvedBy?: string;
  resolvedAt?: string;
  correctiveActionTaken?: string;
  notes?: string;
}

export interface CorrectiveActionLog {
  id: string;
  alertId?: string;
  deviceId: string;
  batchIds: string[];
  actionType: 
    | 'Replaced Dry Ice / PCM Packs'
    | 'Switched to Backup Power'
    | 'Quarantined Batch for Lab QA'
    | 'Transferred Stock to Alternate Fridge'
    | 'Adjusted Thermostat Setpoint'
    | 'Expedited Transport Delivery'
    | 'Cleared Door Obstruction'
    | 'Sensor Re-calibrated'
    | 'Batch Approved for Clinical Administration';
  performedBy: string;
  userRole: UserRole;
  timestamp: string;
  preActionTemp: number;
  postActionTemp?: number;
  safetyStatusAssigned: 'Safe to Administer' | 'Quarantined for Testing' | 'Discard / Invalidate';
  signature: string;
  comments: string;
}

export interface TransportShipment {
  id: string;
  trackingNumber: string;
  deviceId: string;
  carrier: string;
  driverName: string;
  driverPhone: string;
  origin: string;
  destination: string;
  departureTime: string;
  eta: string;
  status: 'In Transit' | 'Delayed' | 'Delivered' | 'Quarantined on Arrival' | 'Preparing';
  coldChainIntegrityScore: number; // 0-100%
  activeBatchCount: number;
  totalDoses: number;
  currentLocation: {
    lat: number;
    lng: number;
    address: string;
  };
  waypoints: {
    name: string;
    lat: number;
    lng: number;
    reached: boolean;
    timestamp?: string;
    tempAtArrival?: number;
  }[];
  handoverChecklist?: {
    vvmStagePassed: boolean; // Vaccine Vial Monitor
    physicalSealIntact: boolean;
    dataLoggerDownloaded: boolean;
    receiverSignature?: string;
    notes?: string;
  };
}

export interface AiRiskAnalysisResult {
  riskScore: number; // 0-100
  riskCategory: RiskLevel;
  primaryRiskFactor: string;
  thermalDecayTimeRemainingMinutes: number; // Time until critical threshold
  predictedTempIn1Hour: number;
  anomalyDetected: string;
  biologicalViabilityImpact: string;
  mktAssessment: string;
  recommendedAction: string;
  rootCauseProbability: {
    powerLoss: number;
    sealLeak: number;
    compressorFault: number;
    ambientExtreme: number;
    sensorDrift: number;
  };
  aiExplanation: string;
}
